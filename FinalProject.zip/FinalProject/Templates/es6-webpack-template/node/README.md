## How to run

*Step 1: make sure you have node  installed on your machine.
*Step 2: enter the command in terminal `npm i`
*Step 3: enter the command `npm start`

